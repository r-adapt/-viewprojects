﻿import java.util.Scanner;// input for user
import java.io.*; 

// add needed for file classes - add version 4 update change
/*Description: creating Modify your code so that it uses the following methods:
public static char displayMainMenu() should prompt for and return the main menu choice.
public static void displayRules() should display the rules to the user.
public static int processQuestion(string q1, string ansA, string ansB,
string ansC, string ansD, char correctAns, int pointValue
public static int readInHighScore() should open “highscore.txt”,
read in the high score, close the file and return the high score.
public static void compareScore(int highScore, int userScore) should
compare the user’s score to the high score that was read from the file.
public static void displayScore(int score) should display the user’s current total*/
//date 7/16/2020
//quizgame version 5

import javax.swing.JOptionPane;// declare for display dialog for input/output
 class javaGamv5 {

   public static void main(String[] args)throws IOException {
    //declare and initialize variable
    String userName;
    int MainMenu;
//  version 4 update useranswer 1-8 var for question and answers choose display from file read
    String userAnswer;
    String quest,ansA, ansB, ansC, ansD, correctAns, Blank;
    int pointValue = 0, userScore = 0;

 // score point var
 // update version 4 change to intgers value for reading from file for user score
  //letter for input for mutiple choice
  //Display Intro
   JOptionPane.showMessageDialog(null,"Welcome to java Trivia game!");
 //display user input
 //Prompt for userName
  userName = JOptionPane.showInputDialog("Please enter your name:");
  do{ // do while for main menu
 //Display main menu
   MainMenu = displayMainMenu();
// menu main take user input choose
   if(MainMenu == 1)
   {
   displayRules();
   }
   else if (MainMenu == 2)
 // be reading File Object for reading
   File rfile = new File("questions.txt");
 // version 4 update for declare Scanner object to write data to file
   Scanner file = new Scanner(rfile);
   for(int i = 0; i < 8; i++)
{
   quest = file.nextLine();
   ansA = file.nextLine();
   ansB = file.nextLine();
   ansC = file.nextLine();
   ansD = file.nextLine();
   correctAns = file.nextLine();
   Blank = file.nextLine();

    userScore += processQuestion(quest, ansA, ansB, ansC, ansD, correctAns, pointValue);
  //result of score from user input valid answer .
 // remove place in method int score display to invoke .
   JOptionPane.showMessageDialog(null,"Your score: " + userScore);
 
 }
file.close();
 }

    else if(MainMenu == 3){
 //display goodbye
   JOptionPane.showMessageDialog(null,"Goodbye");
   }

  else
  {
  JOptionPane.showMessageDialog(null,"Invalid. You must enter 1 - 3.\n");
 }
}while(MainMenu !=3);
}//end of main method


   public static int readInHighScore(){
     int highScore = 0;
//   declare file for highscore.txt  File point = new File ("highscore.txt" );
     File point = new File("highscore.txt");
//   declare Scanner
     Scanner infile  = new Scanner(point);
/  /Read in highScore
     highScore = infile.nextInt();  
//   close file
     infile.close();
  //return highScore;
    return highScore;
}




  public static void compareScore(int highScore, int Score)
   {
   if( Score > highScore)
   {
  //declare a output file for highscore.txt File point = new File 
    PrintWriter outfile = new PrintWriter("highscore.txt"); 
  //write highScore to highscore.txt
    outfile.println();
  //close file
  outfile.close(); 
}
} //end compareScore



   public static int displayMainMenu(){ // reseach better concept to turn char to int method // or changed to string
    int mainMenu;
//  return main menu
    mainMenu = Integer.parseInt(JOptionPane.showInputDialog("main menu:\n1)See rules\n 2)Play Game\n 3)Exit"));
    return mainMenu;
}



   public static void displayScore(int score){
  //display score in a message dialog box
    JOptionPane.showMessageDialog(null,"Your score: " + score);// fix that code up 
}
//method definitions




  public static void displayRules(){
   JOptionPane.showMessageDialog(null,"Quiz Game Rule\n question are multiple-choice\n question is answer incorrect no point\n" +
   "question is answer correct get point\nafter all question are answer point get total to togther");
}




  public static int processQuestion(String q, String ansA, String ansB, String ansC, String ansD, String correctAns, int pointValue)
{
   String userAnswer;
    do
    {
    userAnswer = JOptionPane.showInputDialog(q + "\nA)" + ansA + "\nB)" + ansB +"\nC)" + ansC +"\nD)" + ansD);
    if(userAnswer.equals(correctAns)){
    JOptionPane.showMessageDialog(null,"correct");

    }
     else if (!userAnswer.equalsIgnoreCase("a") && !userAnswer.equalsIgnoreCase("b") &&  !userAnswer.equalsIgnoreCase("c")&& !userAnswer.equalsIgnoreCase("d"))
    {
     JOptionPane.showMessageDialog(null,"Invalid. You must choose A - D ");
    }
 
     else {
    JOptionPane.showMessageDialog(null,"Incorrect.  The correct answer is " + correctAns);
    }

  // add to all question and answer to valid with do while
   }while(!userAnswer.equalsIgnoreCase("a")&&!userAnswer.equalsIgnoreCase("b")&&!userAnswer.equalsIgnoreCase("c")&&!userAnswer.equalsIgnoreCase("d"));

    return pointValue;
 }
}
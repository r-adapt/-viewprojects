﻿   
    
}     
    
}                                                                           //end compareScore
public static int displayMainMenu(){ // reseach better concept to turn char to int method // or changed to string
int mainMenu;
// return main menu
mainMenu = Integer.parseInt(JOptionPane.showInputDialog("main menu:\n1)See rules\n 2)Play Game\n 3)Exit"));
return mainMenu;
}
public static void displayScore(int score){
//display score in a message dialog box
JOptionPane.showMessageDialog(null,"Your score: " + score);// fix that code up 
}
//method definitions
public static void displayRules(){
JOptionPane.showMessageDialog(null,"Quiz Game Rule\n question are multiple-choice\n question is answer incorrect no point\n" +
"question is answer correct get point\nafter all question are answer point get total to togther");
}
public static int processQuestion(String quest[], String ansA[], String ansB[], String ansC[], String ansD[], String correctAns[], int pointValue[])
{
String userAnswer;
do
{
userAnswer = JOptionPane.showInputDialog(quest + "\nA)" + ansA + "\nB)" + ansB +
"\nC)" + ansC +"\nD)" + ansD);
if(userAnswer.equals(correctAns)){
JOptionPane.showMessageDialog(null,"correct");
}
else if (!userAnswer.equalsIgnoreCase("a") && !userAnswer.equalsIgnoreCase("b") &&  !userAnswer.equalsIgnoreCase("c")&& !userAnswer.equalsIgnoreCase("d"))
{
JOptionPane.showMessageDialog(null,"Invalid. You must choose A - D ");
}
else {
JOptionPane.showMessageDialog(null,"Incorrect.  The correct answer is " + correctAns);
}
// add to all question and answer to valid with do while
}while(!userAnswer.equalsIgnoreCase("a")&&!userAnswer.equalsIgnoreCase("b")&&!userAnswer.equalsIgnoreCase("c")&&!userAnswer.equalsIgnoreCase("d"));
return pointValue[value];
}
}
   